Page 1: red diagram

![](images/150afc2c3ad145b8d056a13aa4ef634f1ef7b74fa538e2e99b8b7ae775c3aa8f.jpg)

Page 2: blue diagram

![](images/0b4fed34876fa20890eae7b8bfefae354d991b672d61a9f278207a86ea2df6b3.jpg)